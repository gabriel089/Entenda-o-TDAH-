import React from 'react'
import { createRoot } from 'react-dom/client'
import EntendaOTDAH from './EntendaOTDAH.jsx'
import './styles.css'

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <EntendaOTDAH />
  </React.StrictMode>
)
