import React from 'react'
import { motion } from 'framer-motion'
import { Menu, BookOpen, UserCheck, Heart, Search, HelpCircle } from 'lucide-react'

export default function EntendaOTDAH() {
  return (
    <div className="site">
      <header className="site-header">
        <div className="container header-inner">
          <a className="brand" href="#home">
            <div className="logo">T</div>
            <div>
              <h1>Entenda o TDAH</h1>
              <p className="muted">Guia rápido e confiável</p>
            </div>
          </a>
          <nav className="nav">
            <a href="#o-que-e">O que é</a>
            <a href="#diagnostico">Diagnóstico</a>
            <a href="#convivendo">Convivendo</a>
            <a className="btn" href="#contato">Contato</a>
          </nav>
          <button className="hamburger" aria-hidden><Menu /></button>
        </div>
      </header>

      <main className="container main">
        <section id="home" className="hero">
          <div className="hero-left">
            <motion.h2 initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} transition={{delay:0.05}} className="hero-title">
              Entenda o <span className="accent">TDAH</span>
            </motion.h2>
            <p className="lead">Uma introdução clara sobre o Transtorno do Déficit de Atenção e Hiperatividade: tipos, diagnóstico e estratégias práticas para família, escola e vida adulta.</p>
            <div className="hero-actions">
              <a className="btn primary" href="#o-que-e">Saiba mais</a>
              <a className="btn ghost" href="#diagnostico">Diagnóstico</a>
            </div>

            <div className="cards">
              <Card icon={<BookOpen />} title="Informação confiável" text="Conteúdo baseado em guias clínicos e boas práticas." />
              <Card icon={<UserCheck />} title="Para todas as idades" text="Conteúdo para crianças, adolescentes e adultos." />
              <Card icon={<Heart />} title="Apoio prático" text="Estratégias simples para o dia a dia." />
            </div>
          </div>
          <div className="hero-right">
            <HeroIllustration />
          </div>
        </section>

        <section id="o-que-e" className="section">
          <SectionTitle icon={<HelpCircle />} title="O que é o TDAH" subtitle="Principais características e tipos" />
          <div className="grid3">
            <InfoCard title="TDAH Desatento" text="Dificuldade em manter foco, organização e completar tarefas. Predomina a desatenção sem hiperatividade significativa." />
            <InfoCard title="TDAH Hiperativo-Impulsivo" text="Inquietação motora, agir sem pensar e dificuldade em permanecer sentado." />
            <InfoCard title="TDAH Combinado" text="Sintomas significativos de desatenção e hiperatividade/impulsividade simultaneamente." />
          </div>

          <div className="white-card">
            <h3>Sintomas principais</h3>
            <ul className="symptoms">
              <li>Perda frequente de objetos</li>
              <li>Esquecimento de compromissos</li>
              <li>Dificuldade em seguir instruções</li>
              <li>Inquietação motora</li>
              <li>Respostas precipitadas</li>
              <li>Baixa tolerância à frustração</li>
            </ul>
          </div>
        </section>

        <section id="diagnostico" className="section">
          <SectionTitle icon={<Search />} title="Diagnóstico e Tratamento" subtitle="Como é avaliado e opções de intervenção" />
          <div className="two-col">
            <div className="white-card">
              <h4>Como é feito o diagnóstico</h4>
              <ol className="list">
                <li>Avaliação clínica e entrevista com paciente/família</li>
                <li>Escalas e questionários padronizados</li>
                <li>Avaliação neuropsicológica (quando indicada)</li>
                <li>Exclusão de outras condições e uso dos critérios do DSM-5</li>
              </ol>
              <p className="muted small">O diagnóstico formal é realizado por médico (psiquiatra ou neurologista). Psicólogos realizam avaliações complementares.</p>
            </div>
            <div className="white-card">
              <h4>Tratamentos comuns</h4>
              <ul className="list">
                <li><strong>Medicação:</strong> estimulantes (metilfenidato), não-estimulantes (atomoxetina) — conforme avaliação médica.</li>
                <li><strong>Psicoterapia:</strong> TCC e treinamento de habilidades executivas.</li>
                <li><strong>Intervenções práticas:</strong> coaching, organização, rotinas e suporte escolar.</li>
              </ul>
              <p className="muted small">A combinação de medicação (quando indicada) e terapia costuma trazer melhores resultados.</p>
            </div>
          </div>
        </section>

        <section id="convivendo" className="section">
          <SectionTitle icon={<UserCheck />} title="Convivendo com o TDAH" subtitle="Estratégias práticas para o dia a dia" />
          <div className="two-col">
            <div>
              <h4>Dicas rápidas</h4>
              <ul className="list">
                <li>Use listas visuais, cores e post-its para organizar tarefas.</li>
                <li>Divida tarefas grandes em etapas pequenas e acionáveis.</li>
                <li>Use timers (Pomodoro) e bloqueadores de distração no celular.</li>
                <li>Estabeleça rotinas fixas para sono, alimentação e trabalho.</li>
              </ul>

              <h4>Papel da família e escola</h4>
              <p className="muted">Família e escola devem oferecer estrutura, reforço positivo e adaptações (ex.: tempo extra em provas, instruções por escrito, assentos próximos ao professor).</p>
            </div>
            <div className="white-card">
              <h4>Mitos e Verdades</h4>
              <Disclosure title="Mito: TDAH é falta de disciplina" content="Verdade: é um transtorno neurobiológico com bases genéticas e alterações cerebrais." />
              <Disclosure title="Mito: Medicação vicia" content="Verdade: quando prescrita corretamente, a medicação melhora funcionamento sem causar dependência clínica." />
              <Disclosure title="Mito: Só crianças têm TDAH" content="Verdade: muitos mantêm sintomas na vida adulta; diagnóstico em adultos é comum." />
            </div>
          </div>
        </section>

        <section id="contato" className="section">
          <div className="white-card two-col">
            <div>
              <h4>Fale com a equipe</h4>
              <p className="muted">Se quiser, deixe uma mensagem — este é um protótipo sem backend.</p>
              <form onSubmit={(e)=>e.preventDefault()} className="contact-form">
                <input placeholder="Nome" />
                <input placeholder="Email" />
                <textarea placeholder="Escreva sua dúvida..." rows="4"></textarea>
                <button className="btn primary" type="submit">Enviar (protótipo)</button>
              </form>
            </div>
            <div>
              <h4>Recursos rápidos</h4>
              <ul className="list muted">
                <li>Informações sobre diagnóstico e tratamento</li>
                <li>Estratégias práticas para rotina</li>
                <li>Suporte para família e escola</li>
              </ul>
              <p className="small muted">Este protótipo foi gerado automaticamente. Para publicação real, recomendo revisão por especialista e adicionar referências.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-inner">
          <div>© {new Date().getFullYear()} Entenda o TDAH — Protótipo</div>
          <div className="muted">Feito como protótipo educativo</div>
        </div>
      </footer>
    </div>
  )
}

function Card({icon, title, text}){
  return (
    <div className="mini-card">
      <div className="mini-icon">{icon}</div>
      <div>
        <div className="mini-title">{title}</div>
        <div className="muted small">{text}</div>
      </div>
    </div>
  )
}

function SectionTitle({icon, title, subtitle}){
  return (
    <div className="section-title">
      <div className="section-icon">{icon}</div>
      <div>
        <h3>{title}</h3>
        <div className="muted small">{subtitle}</div>
      </div>
    </div>
  )
}

function InfoCard({title, text}){
  return (
    <div className="info-card white-card">
      <h4>{title}</h4>
      <p className="muted">{text}</p>
    </div>
  )
}

function Disclosure({title, content}){
  const [open, setOpen] = React.useState(false)
  return (
    <div className="disclosure">
      <button className="disclosure-btn" onClick={()=>setOpen(v=>!v)}>
        <span>{title}</span>
        <span>{open? '—' : '+'}</span>
      </button>
      {open && <div className="disclosure-content">{content}</div>}
    </div>
  )
}

function HeroIllustration(){
  return (
    <div className="illustration">
      <svg width="320" height="220" viewBox="0 0 320 220" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="320" height="220" rx="12" fill="#EFF6FF" />
        <circle cx="70" cy="80" r="36" fill="#C7F0FF" />
        <rect x="120" y="40" width="160" height="28" rx="6" fill="#E6EEF9" />
        <rect x="120" y="80" width="160" height="18" rx="4" fill="#E6EEF9" />
        <rect x="120" y="110" width="110" height="18" rx="4" fill="#E6EEF9" />
      </svg>
    </div>
  )
}
